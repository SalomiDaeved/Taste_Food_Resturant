﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.AxHost;

namespace Taste_Food_Resturant
{
    public partial class Form1 : Form
    {
        public HorizontalAlignment Center { get; private set; }
        public object PancakeTb { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Datalbl.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Datalbl.Text = DateTime.Now.ToLongTimeString();
        }

        private void FriesCb_CheckedChanged(object sender, EventArgs e)
        {
            if (FriesCb.Checked == true)
            {
                FriesTb.Enabled = true;
            }
            if (FriesCb.Checked == false)
            {

                FriesTb.Enabled = false;
                FriesTb.Text = "0";

            }
        }

        private void ColaTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void BurgerTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void ChickenTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void SaladTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void CheeseTd_TextChanged(object sender, EventArgs e)
        {

        }

        private void PastaTd_TextChanged(object sender, EventArgs e)
        {

        }

        private void FriesTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void TeaTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void BurgerCb_CheckedChanged(object sender, EventArgs e)
        {
            if (BurgerCb.Checked == true)
            {
                BurgerTb.Enabled = true;
            }
            if (BurgerCb.Checked == false)
            {

                BurgerTb.Enabled = false;
                BurgerTb.Text = "0";

            }
        }

        private void ChickenCb_CheckedChanged(object sender, EventArgs e)
        {

            if (ChickenCb.Checked == true)
            {
                ChickenTb.Enabled = true;
            }
            if (ChickenCb.Checked == false)
            {

                ChickenTb.Enabled = false;
                ChickenTb.Text = "0";

            }

        }

        private void SaladCb_CheckedChanged(object sender, EventArgs e)
        {
            if (SaladCb.Checked == true)
            {
                SaladTb.Enabled = true;
            }
            if (SaladCb.Checked == false)
            {

                SaladTb.Enabled = false;
                SaladTb.Text = "0";

            }

        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox1.Checked == true)
            {
                CheeseTb.Enabled = true;
            }
            if (checkBox1.Checked == false)
            {

                CheeseTb.Enabled = false;
                CheeseTb.Text = "0";

            }

        }

        private void PastaCb_CheckedChanged(object sender, EventArgs e)
        {

            if (PastaCb.Checked == true)
            {
                PastaTb.Enabled = true;
            }
            if (PastaCb.Checked == false)
            {

                PastaTb.Enabled = false;
                PastaTb.Text = "0";

            }
        }

        private void ColaCb_CheckedChanged(object sender, EventArgs e)
        {
            if (ColaCb.Checked == true)
            {
                ColaTb.Enabled = true;
            }
            if (ColaCb.Checked == false)
            {

                ColaTb.Enabled = false;
                ColaTb.Text = "0";

            }

        }

        private void TeaCb_CheckedChanged(object sender, EventArgs e)
        {
            if (TeaCb.Checked == true)
            {
                TeaTb.Enabled = true;
            }
            if (TeaCb.Checked == false)
            {

                TeaTb.Enabled = false;
                TeaTb.Text = "0";

            }
        }

        private void WaterCb_CheckedChanged(object sender, EventArgs e)
        {
            if (WaterCb.Checked == true)
            {
                WaterTd.Enabled = true;
            }
            if (WaterCb.Checked == false)
            {

                WaterCb.Enabled = false;
                WaterTd.Text = "0";

            }
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ChocoCb_CheckedChanged(object sender, EventArgs e)
        {
            if (ChocoCb.Checked == true)
            {
                ChocoTb.Enabled = true;
            }
            if (ChocoCb.Checked == false)
            {

                ChocoTb.Enabled = false;
                ChocoTb.Text = "0";

            }
        }

        private void OrangeCb_CheckedChanged(object sender, EventArgs e)
        {
            if (OrangeCb.Checked == true)
            {
                OrangeTb.Enabled = true;
            }
            if (OrangeCb.Checked == false)
            {

                OrangeCb.Enabled = false;
                OrangeTb.Text = "0";

            }
        }

        private void PancakeCb_CheckedChanged(object sender, EventArgs e)
        {
            if (PancakeCb.Checked == true)
            {
                PancakeTd.Enabled = true;
            }
            if (PancakeCb.Checked == false)
            {

                PancakeTd.Enabled = false;
                PancakeTd.Text = "0";

            }
        }

        private void Closelbl_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            FriesCb.Checked = false;
            BurgerCb.Checked = false;   
            SaladCb.Checked = false;
            ChickenCb.Checked = false;
            PastaCb.Checked = false;
            checkBox1.Checked = false;
            ColaCb.Checked = false;
            WaterCb.Checked = false;
            TeaCb.Checked = false;
            OrangeCb.Checked = false;
            PancakeCb.Checked = false;
            ChocoCb.Checked = false;





        }
        double Friesup = 400, Burgerup = 750, Saladup = 350, Chickenup = 500, Cheeseup = 600, Pastaup = 250,
            Waterup = 150, Colaup = 200, Orangeup = 370, Teaup = 170, Chocoup = 200, Pancakeup = 100;

        private void button3_Click(object sender, EventArgs e)
        {
            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print();
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        { e.Graphics.DrawString(RecieptTb.Text + "Subtotal:   "   + subtotallbl.Text +    "Tax:  " + Taxlbl.Text+
            "Grand Total: "   + Totlbl.Text, new Font("Century Gothic", 12, FontStyle.Regular), Brushes.Blue, new Point(130));
           
            

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void PancakeTd_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        double Friestp, Burgertp, Saladtp, Chickentp, Cheesetp, Pastatp, Watertp, Colatp, Orangetp, Teatp, Chocotp, Pancaketp;
        double subtotal = 0, tax, gratot;
        private void button2_Click(object sender, EventArgs e)
        {
            Friestp = Friesup * Convert.ToDouble(FriesTb.Text);
            Burgertp = Burgerup * Convert.ToDouble(BurgerTb.Text);
            Saladtp = Saladup * Convert.ToDouble(SaladTb.Text);
            Chickentp =Chickenup * Convert.ToDouble(ChickenTb.Text);
            Cheesetp = Cheeseup * Convert.ToDouble(CheeseTb.Text);
            Pastatp = Pastaup * Convert.ToDouble(PastaTb.Text);
            Watertp = Waterup * Convert.ToDouble(WaterTd.Text);
            Colatp = Colaup * Convert.ToDouble(ColaTb.Text);
            Orangetp = Orangeup * Convert.ToDouble(OrangeTb.Text);
            Teatp = Teaup * Convert.ToDouble(TeaTb.Text);
           Chocotp = Chocoup * Convert.ToDouble(ChocoTb.Text);
            Pancaketp = Pancakeup * Convert.ToDouble(PancakeTd.Text);

            RecieptTb.Clear();
            subtotal = 0;
            RecieptTb.AppendText(Environment.NewLine);
            RecieptTb.AppendText("\t\t\tGALLERY RESTURANT  " +Datalbl.Text+ Environment.NewLine);
            RecieptTb.AppendText("\t\t\t******************************"+Environment.NewLine);
            tax = 0;
            gratot = 0;


          if(FriesCb.Checked==true)
            {
                RecieptTb.AppendText("\tFries\t" + Friestp + "RS" + Environment.NewLine);
                subtotal = subtotal + Friestp;
                subtotallbl.Text = " " + subtotal;

            }

            if (BurgerCb.Checked == true)
            {
                RecieptTb.AppendText("\tBurger\t" + Burgertp + "RS" + Environment.NewLine);
                subtotal = subtotal + Burgertp;
                subtotallbl.Text = " " + subtotal;

            }

            if (ChickenCb.Checked == true)
            {
                RecieptTb.AppendText("\tChicken\t" + Chickentp + "RS" + Environment.NewLine);
                subtotal = subtotal + Chickentp;
                subtotallbl.Text = " " + subtotal;

            }

            if (SaladCb.Checked == true)
            {
                RecieptTb.AppendText("\tSalad\t" + Saladtp + "RS" + Environment.NewLine);
                subtotal = subtotal + Saladtp;
                subtotallbl.Text = " " + subtotal;

            }



            if (checkBox1.Checked == true)
            {
                RecieptTb.AppendText("\tCheese\t" + Cheesetp + "RS" + Environment.NewLine);
                subtotal = subtotal + Cheesetp;
                subtotallbl.Text = " " + subtotal;

            }
            if (PastaCb.Checked == true)
            {
                RecieptTb.AppendText("\tPasta\t" + Pastatp + "RS" + Environment.NewLine);
                subtotal = subtotal + Pastatp;
                subtotallbl.Text = " " + subtotal;

            }

            if (ColaCb.Checked == true)
            {
                RecieptTb.AppendText("\tCola\t" + Colatp + "RS" + Environment.NewLine);
                subtotal = subtotal + Colatp;
                subtotallbl.Text = " " + subtotal;

            }

            if (WaterCb.Checked == true)
            {
                RecieptTb.AppendText("\tWater\t" + Watertp + "RS" + Environment.NewLine);
                subtotal = subtotal + Watertp;
                subtotallbl.Text = " " + subtotal;

            }

            if (TeaCb.Checked == true)
            {
                RecieptTb.AppendText("\tTea\t" +Teatp + "RS" + Environment.NewLine);
                subtotal = subtotal + Teatp;
                subtotallbl.Text = " " + subtotal;

            }

            if (ChocoCb.Checked == true)
            {
                RecieptTb.AppendText("\tChoco\t" + Chocotp + "RS" + Environment.NewLine);
                subtotal = subtotal + Chocotp;
                subtotallbl.Text = " " + subtotal;

            }

            if (OrangeCb.Checked == true)
            {
                RecieptTb.AppendText("\tOrange\t" + Orangetp + "RS" + Environment.NewLine);
                subtotal = subtotal + Orangetp;
                subtotallbl.Text = " " + subtotal;

            }

            if (PancakeCb.Checked == true)
            {
                RecieptTb.AppendText("\tPancake\t" + Pancaketp + "RS" + Environment.NewLine);
                subtotal = subtotal + Pancaketp;
                subtotallbl.Text = " " + subtotal;

            }

            tax = subtotal * 0.16;
            gratot = subtotal + tax;
            Taxlbl.Text = "RS" + tax;
            Totlbl.Text = "RS" + gratot;











        }
    } }
    

