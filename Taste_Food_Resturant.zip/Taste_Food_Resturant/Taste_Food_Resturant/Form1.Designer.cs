﻿namespace Taste_Food_Resturant
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.Closelbl = new System.Windows.Forms.Label();
            this.Datalbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.ChocoTb = new System.Windows.Forms.TextBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.ChocoCb = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.OrangeTb = new System.Windows.Forms.TextBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.OrangeCb = new System.Windows.Forms.CheckBox();
            this.label12 = new System.Windows.Forms.Label();
            this.PancakeTd = new System.Windows.Forms.TextBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.PancakeCb = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.WaterTd = new System.Windows.Forms.TextBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.WaterCb = new System.Windows.Forms.CheckBox();
            this.label14 = new System.Windows.Forms.Label();
            this.TeaTb = new System.Windows.Forms.TextBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.TeaCb = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.ColaTb = new System.Windows.Forms.TextBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.ColaCb = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.SaladTb = new System.Windows.Forms.TextBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.SaladCb = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.CheeseTb = new System.Windows.Forms.TextBox();
            this.CheeseCb = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.PastaTb = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.PastaCb = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ChickenTb = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.ChickenCb = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.BurgerTb = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.BurgerCb = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.FriesTb = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.FriesCb = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel12 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Totlbl = new System.Windows.Forms.Label();
            this.Taxlbl = new System.Windows.Forms.Label();
            this.subtotallbl = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.RecieptTb = new System.Windows.Forms.RichTextBox();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CheeseCb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel7.SuspendLayout();
            this.panel12.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.Closelbl);
            this.panel1.Controls.Add(this.Datalbl);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1338, 119);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Closelbl
            // 
            this.Closelbl.AutoSize = true;
            this.Closelbl.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Closelbl.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.Closelbl.Location = new System.Drawing.Point(1216, 9);
            this.Closelbl.Name = "Closelbl";
            this.Closelbl.Size = new System.Drawing.Size(80, 29);
            this.Closelbl.TabIndex = 32;
            this.Closelbl.Text = "Close";
            this.Closelbl.Click += new System.EventHandler(this.Closelbl_Click);
            // 
            // Datalbl
            // 
            this.Datalbl.AutoSize = true;
            this.Datalbl.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datalbl.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.Datalbl.Location = new System.Drawing.Point(1091, 63);
            this.Datalbl.Name = "Datalbl";
            this.Datalbl.Size = new System.Drawing.Size(142, 29);
            this.Datalbl.TabIndex = 31;
            this.Datalbl.Text = "Fast Meals";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.label1.Location = new System.Drawing.Point(373, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(592, 55);
            this.label1.TabIndex = 0;
            this.label1.Text = "GALLERY FAST RESTURANT";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(990, 119);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(348, 706);
            this.panel2.TabIndex = 2;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this.ChocoTb);
            this.panel6.Controls.Add(this.pictureBox8);
            this.panel6.Controls.Add(this.ChocoCb);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.OrangeTb);
            this.panel6.Controls.Add(this.pictureBox9);
            this.panel6.Controls.Add(this.OrangeCb);
            this.panel6.Controls.Add(this.label12);
            this.panel6.Controls.Add(this.PancakeTd);
            this.panel6.Controls.Add(this.pictureBox10);
            this.panel6.Controls.Add(this.PancakeCb);
            this.panel6.Controls.Add(this.label13);
            this.panel6.Controls.Add(this.WaterTd);
            this.panel6.Controls.Add(this.pictureBox11);
            this.panel6.Controls.Add(this.WaterCb);
            this.panel6.Controls.Add(this.label14);
            this.panel6.Controls.Add(this.TeaTb);
            this.panel6.Controls.Add(this.pictureBox12);
            this.panel6.Controls.Add(this.TeaCb);
            this.panel6.Controls.Add(this.label15);
            this.panel6.Controls.Add(this.ColaTb);
            this.panel6.Controls.Add(this.pictureBox7);
            this.panel6.Controls.Add(this.ColaCb);
            this.panel6.Controls.Add(this.label16);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(314, 706);
            this.panel6.TabIndex = 7;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.SeaGreen;
            this.label10.Location = new System.Drawing.Point(46, 15);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(252, 29);
            this.label10.TabIndex = 29;
            this.label10.Text = "Drinks and Desserts";
            // 
            // ChocoTb
            // 
            this.ChocoTb.Enabled = false;
            this.ChocoTb.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChocoTb.Location = new System.Drawing.Point(231, 315);
            this.ChocoTb.Multiline = true;
            this.ChocoTb.Name = "ChocoTb";
            this.ChocoTb.Size = new System.Drawing.Size(77, 57);
            this.ChocoTb.TabIndex = 28;
            this.ChocoTb.Text = "0";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::Taste_Food_Resturant.Properties.Resources._7035646;
            this.pictureBox8.Location = new System.Drawing.Point(51, 315);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(74, 47);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 27;
            this.pictureBox8.TabStop = false;
            // 
            // ChocoCb
            // 
            this.ChocoCb.AutoSize = true;
            this.ChocoCb.Location = new System.Drawing.Point(23, 335);
            this.ChocoCb.Name = "ChocoCb";
            this.ChocoCb.Size = new System.Drawing.Size(22, 21);
            this.ChocoCb.TabIndex = 26;
            this.ChocoCb.UseVisualStyleBackColor = true;
            this.ChocoCb.CheckedChanged += new System.EventHandler(this.ChocoCb_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.SeaGreen;
            this.label11.Location = new System.Drawing.Point(135, 332);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(71, 24);
            this.label11.TabIndex = 25;
            this.label11.Text = "Choco";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // OrangeTb
            // 
            this.OrangeTb.Enabled = false;
            this.OrangeTb.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrangeTb.Location = new System.Drawing.Point(231, 395);
            this.OrangeTb.Multiline = true;
            this.OrangeTb.Name = "OrangeTb";
            this.OrangeTb.Size = new System.Drawing.Size(77, 57);
            this.OrangeTb.TabIndex = 24;
            this.OrangeTb.Text = "0";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Taste_Food_Resturant.Properties.Resources._721098;
            this.pictureBox9.Location = new System.Drawing.Point(51, 395);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(74, 47);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 23;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Click += new System.EventHandler(this.pictureBox9_Click);
            // 
            // OrangeCb
            // 
            this.OrangeCb.AutoSize = true;
            this.OrangeCb.Location = new System.Drawing.Point(23, 413);
            this.OrangeCb.Name = "OrangeCb";
            this.OrangeCb.Size = new System.Drawing.Size(22, 21);
            this.OrangeCb.TabIndex = 22;
            this.OrangeCb.UseVisualStyleBackColor = true;
            this.OrangeCb.CheckedChanged += new System.EventHandler(this.OrangeCb_CheckedChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.SeaGreen;
            this.label12.Location = new System.Drawing.Point(135, 412);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 24);
            this.label12.TabIndex = 21;
            this.label12.Text = "Orange";
            // 
            // PancakeTd
            // 
            this.PancakeTd.Enabled = false;
            this.PancakeTd.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PancakeTd.Location = new System.Drawing.Point(231, 481);
            this.PancakeTd.Multiline = true;
            this.PancakeTd.Name = "PancakeTd";
            this.PancakeTd.Size = new System.Drawing.Size(77, 57);
            this.PancakeTd.TabIndex = 20;
            this.PancakeTd.Text = "0";
            this.PancakeTd.TextChanged += new System.EventHandler(this.PancakeTd_TextChanged);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::Taste_Food_Resturant.Properties.Resources._5814149;
            this.pictureBox10.Location = new System.Drawing.Point(51, 481);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(74, 47);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 19;
            this.pictureBox10.TabStop = false;
            // 
            // PancakeCb
            // 
            this.PancakeCb.AutoSize = true;
            this.PancakeCb.Location = new System.Drawing.Point(23, 498);
            this.PancakeCb.Name = "PancakeCb";
            this.PancakeCb.Size = new System.Drawing.Size(22, 21);
            this.PancakeCb.TabIndex = 18;
            this.PancakeCb.UseVisualStyleBackColor = true;
            this.PancakeCb.CheckedChanged += new System.EventHandler(this.PancakeCb_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.SeaGreen;
            this.label13.Location = new System.Drawing.Point(136, 491);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(95, 24);
            this.label13.TabIndex = 17;
            this.label13.Text = "Pancake";
            // 
            // WaterTd
            // 
            this.WaterTd.Enabled = false;
            this.WaterTd.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WaterTd.Location = new System.Drawing.Point(231, 235);
            this.WaterTd.Multiline = true;
            this.WaterTd.Name = "WaterTd";
            this.WaterTd.Size = new System.Drawing.Size(77, 57);
            this.WaterTd.TabIndex = 16;
            this.WaterTd.Text = "0";
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::Taste_Food_Resturant.Properties.Resources.W;
            this.pictureBox11.Location = new System.Drawing.Point(51, 235);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(74, 47);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 15;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // WaterCb
            // 
            this.WaterCb.AutoSize = true;
            this.WaterCb.Location = new System.Drawing.Point(23, 252);
            this.WaterCb.Name = "WaterCb";
            this.WaterCb.Size = new System.Drawing.Size(22, 21);
            this.WaterCb.TabIndex = 14;
            this.WaterCb.UseVisualStyleBackColor = true;
            this.WaterCb.CheckedChanged += new System.EventHandler(this.WaterCb_CheckedChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.SeaGreen;
            this.label14.Location = new System.Drawing.Point(135, 247);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 24);
            this.label14.TabIndex = 13;
            this.label14.Text = "Water ";
            // 
            // TeaTb
            // 
            this.TeaTb.Enabled = false;
            this.TeaTb.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TeaTb.Location = new System.Drawing.Point(231, 153);
            this.TeaTb.Multiline = true;
            this.TeaTb.Name = "TeaTb";
            this.TeaTb.Size = new System.Drawing.Size(77, 57);
            this.TeaTb.TabIndex = 12;
            this.TeaTb.Text = "0";
            this.TeaTb.TextChanged += new System.EventHandler(this.TeaTb_TextChanged);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::Taste_Food_Resturant.Properties.Resources._4645890;
            this.pictureBox12.Location = new System.Drawing.Point(51, 162);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(74, 47);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 11;
            this.pictureBox12.TabStop = false;
            // 
            // TeaCb
            // 
            this.TeaCb.AutoSize = true;
            this.TeaCb.Location = new System.Drawing.Point(23, 170);
            this.TeaCb.Name = "TeaCb";
            this.TeaCb.Size = new System.Drawing.Size(22, 21);
            this.TeaCb.TabIndex = 10;
            this.TeaCb.UseVisualStyleBackColor = true;
            this.TeaCb.CheckedChanged += new System.EventHandler(this.TeaCb_CheckedChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.SeaGreen;
            this.label15.Location = new System.Drawing.Point(131, 167);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(46, 24);
            this.label15.TabIndex = 9;
            this.label15.Text = "Tea";
            // 
            // ColaTb
            // 
            this.ColaTb.Enabled = false;
            this.ColaTb.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ColaTb.Location = new System.Drawing.Point(231, 77);
            this.ColaTb.Multiline = true;
            this.ColaTb.Name = "ColaTb";
            this.ColaTb.Size = new System.Drawing.Size(77, 57);
            this.ColaTb.TabIndex = 8;
            this.ColaTb.Text = "0";
            this.ColaTb.TextChanged += new System.EventHandler(this.ColaTb_TextChanged);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::Taste_Food_Resturant.Properties.Resources.C;
            this.pictureBox7.Location = new System.Drawing.Point(51, 87);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(74, 47);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 7;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // ColaCb
            // 
            this.ColaCb.AutoSize = true;
            this.ColaCb.Location = new System.Drawing.Point(23, 99);
            this.ColaCb.Name = "ColaCb";
            this.ColaCb.Size = new System.Drawing.Size(22, 21);
            this.ColaCb.TabIndex = 6;
            this.ColaCb.UseVisualStyleBackColor = true;
            this.ColaCb.CheckedChanged += new System.EventHandler(this.ColaCb_CheckedChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.SeaGreen;
            this.label16.Location = new System.Drawing.Point(131, 99);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 24);
            this.label16.TabIndex = 5;
            this.label16.Text = "Cola";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.SeaGreen;
            this.label3.Location = new System.Drawing.Point(18, 15);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(240, 29);
            this.label3.TabIndex = 6;
            this.label3.Text = "Drink and Desserts";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(319, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(29, 706);
            this.panel5.TabIndex = 5;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.checkBox1);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.SaladTb);
            this.panel3.Controls.Add(this.pictureBox6);
            this.panel3.Controls.Add(this.SaladCb);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.CheeseTb);
            this.panel3.Controls.Add(this.CheeseCb);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.PastaTb);
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Controls.Add(this.PastaCb);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.ChickenTb);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Controls.Add(this.ChickenCb);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.BurgerTb);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Controls.Add(this.BurgerCb);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.FriesTb);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Controls.Add(this.FriesCb);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 119);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(314, 706);
            this.panel3.TabIndex = 3;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(35, 407);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(22, 21);
            this.checkBox1.TabIndex = 30;
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Rockwell", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.SeaGreen;
            this.label9.Location = new System.Drawing.Point(92, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(142, 29);
            this.label9.TabIndex = 29;
            this.label9.Text = "Fast Meals";
            // 
            // SaladTb
            // 
            this.SaladTb.Enabled = false;
            this.SaladTb.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaladTb.Location = new System.Drawing.Point(231, 315);
            this.SaladTb.Multiline = true;
            this.SaladTb.Name = "SaladTb";
            this.SaladTb.Size = new System.Drawing.Size(77, 57);
            this.SaladTb.TabIndex = 28;
            this.SaladTb.Text = "0";
            this.SaladTb.TextChanged += new System.EventHandler(this.SaladTb_TextChanged);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Taste_Food_Resturant.Properties.Resources._184559;
            this.pictureBox6.Location = new System.Drawing.Point(64, 315);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(74, 47);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 27;
            this.pictureBox6.TabStop = false;
            // 
            // SaladCb
            // 
            this.SaladCb.AutoSize = true;
            this.SaladCb.Location = new System.Drawing.Point(36, 332);
            this.SaladCb.Name = "SaladCb";
            this.SaladCb.Size = new System.Drawing.Size(22, 21);
            this.SaladCb.TabIndex = 26;
            this.SaladCb.UseVisualStyleBackColor = true;
            this.SaladCb.CheckedChanged += new System.EventHandler(this.SaladCb_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.SeaGreen;
            this.label8.Location = new System.Drawing.Point(144, 332);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 24);
            this.label8.TabIndex = 25;
            this.label8.Text = "Salad";
            // 
            // CheeseTb
            // 
            this.CheeseTb.Enabled = false;
            this.CheeseTb.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheeseTb.Location = new System.Drawing.Point(231, 395);
            this.CheeseTb.Multiline = true;
            this.CheeseTb.Name = "CheeseTb";
            this.CheeseTb.Size = new System.Drawing.Size(77, 57);
            this.CheeseTb.TabIndex = 24;
            this.CheeseTb.Text = "0";
            this.CheeseTb.TextChanged += new System.EventHandler(this.CheeseTd_TextChanged);
            // 
            // CheeseCb
            // 
            this.CheeseCb.Image = global::Taste_Food_Resturant.Properties.Resources._64_647930_cheddar_cheese_food_pixabay_transparent_background_cheese_clipart;
            this.CheeseCb.Location = new System.Drawing.Point(64, 395);
            this.CheeseCb.Name = "CheeseCb";
            this.CheeseCb.Size = new System.Drawing.Size(74, 47);
            this.CheeseCb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.CheeseCb.TabIndex = 23;
            this.CheeseCb.TabStop = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.SeaGreen;
            this.label7.Location = new System.Drawing.Point(144, 413);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 24);
            this.label7.TabIndex = 21;
            this.label7.Text = "Cheese";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // PastaTb
            // 
            this.PastaTb.Enabled = false;
            this.PastaTb.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PastaTb.Location = new System.Drawing.Point(231, 481);
            this.PastaTb.Multiline = true;
            this.PastaTb.Name = "PastaTb";
            this.PastaTb.Size = new System.Drawing.Size(77, 57);
            this.PastaTb.TabIndex = 20;
            this.PastaTb.Text = "0";
            this.PastaTb.TextChanged += new System.EventHandler(this.PastaTd_TextChanged);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Taste_Food_Resturant.Properties.Resources.pngtree_pasta_or_spaghetti_icon_png_image_8876666;
            this.pictureBox4.Location = new System.Drawing.Point(64, 491);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(74, 47);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 19;
            this.pictureBox4.TabStop = false;
            // 
            // PastaCb
            // 
            this.PastaCb.AutoSize = true;
            this.PastaCb.Location = new System.Drawing.Point(36, 498);
            this.PastaCb.Name = "PastaCb";
            this.PastaCb.Size = new System.Drawing.Size(22, 21);
            this.PastaCb.TabIndex = 18;
            this.PastaCb.UseVisualStyleBackColor = true;
            this.PastaCb.CheckedChanged += new System.EventHandler(this.PastaCb_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SeaGreen;
            this.label6.Location = new System.Drawing.Point(144, 498);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 24);
            this.label6.TabIndex = 17;
            this.label6.Text = "Pasta";
            // 
            // ChickenTb
            // 
            this.ChickenTb.Enabled = false;
            this.ChickenTb.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChickenTb.Location = new System.Drawing.Point(231, 235);
            this.ChickenTb.Multiline = true;
            this.ChickenTb.Name = "ChickenTb";
            this.ChickenTb.Size = new System.Drawing.Size(77, 57);
            this.ChickenTb.TabIndex = 16;
            this.ChickenTb.Text = "0";
            this.ChickenTb.TextChanged += new System.EventHandler(this.ChickenTb_TextChanged);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Taste_Food_Resturant.Properties.Resources._4940015;
            this.pictureBox3.Location = new System.Drawing.Point(64, 235);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(74, 47);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            // 
            // ChickenCb
            // 
            this.ChickenCb.AutoSize = true;
            this.ChickenCb.Location = new System.Drawing.Point(36, 252);
            this.ChickenCb.Name = "ChickenCb";
            this.ChickenCb.Size = new System.Drawing.Size(22, 21);
            this.ChickenCb.TabIndex = 14;
            this.ChickenCb.UseVisualStyleBackColor = true;
            this.ChickenCb.CheckedChanged += new System.EventHandler(this.ChickenCb_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.SeaGreen;
            this.label5.Location = new System.Drawing.Point(144, 244);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 24);
            this.label5.TabIndex = 13;
            this.label5.Text = "Chicken";
            // 
            // BurgerTb
            // 
            this.BurgerTb.Enabled = false;
            this.BurgerTb.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BurgerTb.Location = new System.Drawing.Point(231, 153);
            this.BurgerTb.Multiline = true;
            this.BurgerTb.Name = "BurgerTb";
            this.BurgerTb.Size = new System.Drawing.Size(77, 57);
            this.BurgerTb.TabIndex = 12;
            this.BurgerTb.Text = "0";
            this.BurgerTb.TextChanged += new System.EventHandler(this.BurgerTb_TextChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Taste_Food_Resturant.Properties.Resources.images__5_;
            this.pictureBox2.Location = new System.Drawing.Point(64, 153);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(74, 47);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // BurgerCb
            // 
            this.BurgerCb.AutoSize = true;
            this.BurgerCb.Location = new System.Drawing.Point(36, 170);
            this.BurgerCb.Name = "BurgerCb";
            this.BurgerCb.Size = new System.Drawing.Size(22, 21);
            this.BurgerCb.TabIndex = 10;
            this.BurgerCb.UseVisualStyleBackColor = true;
            this.BurgerCb.CheckedChanged += new System.EventHandler(this.BurgerCb_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SeaGreen;
            this.label4.Location = new System.Drawing.Point(144, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 24);
            this.label4.TabIndex = 9;
            this.label4.Text = "Burger";
            // 
            // FriesTb
            // 
            this.FriesTb.Enabled = false;
            this.FriesTb.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FriesTb.Location = new System.Drawing.Point(231, 77);
            this.FriesTb.Multiline = true;
            this.FriesTb.Name = "FriesTb";
            this.FriesTb.Size = new System.Drawing.Size(77, 57);
            this.FriesTb.TabIndex = 8;
            this.FriesTb.Text = "0";
            this.FriesTb.TextChanged += new System.EventHandler(this.FriesTb_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Taste_Food_Resturant.Properties.Resources.images__3_;
            this.pictureBox1.Location = new System.Drawing.Point(64, 77);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(74, 47);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FriesCb
            // 
            this.FriesCb.AutoSize = true;
            this.FriesCb.Location = new System.Drawing.Point(36, 94);
            this.FriesCb.Name = "FriesCb";
            this.FriesCb.Size = new System.Drawing.Size(22, 21);
            this.FriesCb.TabIndex = 6;
            this.FriesCb.UseVisualStyleBackColor = true;
            this.FriesCb.CheckedChanged += new System.EventHandler(this.FriesCb_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.SeaGreen;
            this.label2.Location = new System.Drawing.Point(144, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 24);
            this.label2.TabIndex = 5;
            this.label2.Text = "Fries";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(29, 706);
            this.panel4.TabIndex = 4;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.MediumSpringGreen;
            this.panel7.Controls.Add(this.label17);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel7.Location = new System.Drawing.Point(314, 119);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(676, 519);
            this.panel7.TabIndex = 4;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Rockwell", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(244, 33);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(188, 33);
            this.label17.TabIndex = 30;
            this.label17.Text = "See your bill";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.button3);
            this.panel12.Controls.Add(this.button2);
            this.panel12.Controls.Add(this.Totlbl);
            this.panel12.Controls.Add(this.Taxlbl);
            this.panel12.Controls.Add(this.subtotallbl);
            this.panel12.Controls.Add(this.button1);
            this.panel12.Controls.Add(this.label20);
            this.panel12.Controls.Add(this.label19);
            this.panel12.Controls.Add(this.label18);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel12.Location = new System.Drawing.Point(314, 634);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(676, 191);
            this.panel12.TabIndex = 9;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Black;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Lucida Bright", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.button3.Location = new System.Drawing.Point(479, 83);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(102, 59);
            this.button3.TabIndex = 25;
            this.button3.Text = "PRINT";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Lucida Bright", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.button2.Location = new System.Drawing.Point(297, 83);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(102, 59);
            this.button2.TabIndex = 24;
            this.button2.Text = "ADD";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Totlbl
            // 
            this.Totlbl.AutoSize = true;
            this.Totlbl.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Totlbl.ForeColor = System.Drawing.Color.Black;
            this.Totlbl.Location = new System.Drawing.Point(538, 32);
            this.Totlbl.Name = "Totlbl";
            this.Totlbl.Size = new System.Drawing.Size(79, 29);
            this.Totlbl.TabIndex = 23;
            this.Totlbl.Text = "RS/--";
            // 
            // Taxlbl
            // 
            this.Taxlbl.AutoSize = true;
            this.Taxlbl.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Taxlbl.ForeColor = System.Drawing.Color.Black;
            this.Taxlbl.Location = new System.Drawing.Point(320, 32);
            this.Taxlbl.Name = "Taxlbl";
            this.Taxlbl.Size = new System.Drawing.Size(79, 29);
            this.Taxlbl.TabIndex = 22;
            this.Taxlbl.Text = "RS/--";
            // 
            // subtotallbl
            // 
            this.subtotallbl.AutoSize = true;
            this.subtotallbl.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.subtotallbl.ForeColor = System.Drawing.Color.Black;
            this.subtotallbl.Location = new System.Drawing.Point(120, 32);
            this.subtotallbl.Name = "subtotallbl";
            this.subtotallbl.Size = new System.Drawing.Size(79, 29);
            this.subtotallbl.TabIndex = 21;
            this.subtotallbl.Text = "RS/--";
            this.subtotallbl.Click += new System.EventHandler(this.label21_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Lucida Bright", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.MediumSpringGreen;
            this.button1.Location = new System.Drawing.Point(97, 83);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(102, 59);
            this.button1.TabIndex = 10;
            this.button1.Text = "RESET";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.SeaGreen;
            this.label20.Location = new System.Drawing.Point(462, 32);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(74, 29);
            this.label20.TabIndex = 20;
            this.label20.Text = "Total";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.SeaGreen;
            this.label19.Location = new System.Drawing.Point(267, 32);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(57, 29);
            this.label19.TabIndex = 19;
            this.label19.Text = "Tax";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.SeaGreen;
            this.label18.Location = new System.Drawing.Point(3, 32);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(119, 29);
            this.label18.TabIndex = 18;
            this.label18.Text = "SubTotal";
            // 
            // RecieptTb
            // 
            this.RecieptTb.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.RecieptTb.Location = new System.Drawing.Point(314, 213);
            this.RecieptTb.Name = "RecieptTb";
            this.RecieptTb.Size = new System.Drawing.Size(642, 327);
            this.RecieptTb.TabIndex = 10;
            this.RecieptTb.Text = "";
            this.RecieptTb.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDialog1
            // 
            this.printDialog1.UseEXDialog = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1338, 825);
            this.Controls.Add(this.RecieptTb);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CheeseCb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox FriesCb;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox FriesTb;
        private System.Windows.Forms.TextBox PastaTb;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.CheckBox PastaCb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ChickenTb;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.CheckBox ChickenCb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox BurgerTb;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.CheckBox BurgerCb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox SaladTb;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.CheckBox SaladCb;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox CheeseTb;
        private System.Windows.Forms.PictureBox CheeseCb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox ChocoTb;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.CheckBox ChocoCb;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox OrangeTb;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.CheckBox OrangeCb;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox PancakeTd;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.CheckBox PancakeCb;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox WaterTd;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.CheckBox WaterCb;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox TeaTb;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.CheckBox TeaCb;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox ColaTb;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.CheckBox ColaCb;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label Datalbl;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label Closelbl;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Totlbl;
        private System.Windows.Forms.Label Taxlbl;
        private System.Windows.Forms.Label subtotallbl;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.RichTextBox RecieptTb;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.PrintDialog printDialog1;
    }
}

